# PLANTILLA DE MEMORIA TFM

Modifica las plantillas incluidas en los directorios:
- secciones
- tablas
- algoritmos

Para compilar el documento, ejecuta "make" dentro del repositorio.

Para limpiar la compilación, ejecuta "make clean" dentro del repositorio.
